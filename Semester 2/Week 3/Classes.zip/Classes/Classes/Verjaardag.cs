﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Verjaardag
    {

        // ==== Klassevariabelen ====
        private int maand;

        // ==== READ AND WRITE PROPERTY ====
        public int AantalCadeaus { get; set; }
        public bool IsFeest { get; set; }
        public string MijnBoodschap
        {
            get { return boodschap; }
            set { boodschap = GeeftBericht(value); }
        }







        private string boodschap, naam;
        // ==== CONSTRUCTOR ZONDER PARAMETERS ====
        public Verjaardag()
        { AantalCadeaus = 1; }
        // ==== CONSTRUCTOR MET PARAMETERS ====
        public Verjaardag(string name, DateTime birthday)
        {
            naam = name;
            maand = birthday.Month;
            AantalCadeaus = 5;
            if (maand == DateTime.Today.Month) IsFeest = true;
            MijnBoodschap = naam;
        }

        

        // ==== PRIVATE FUNCTION ====
        private string GeeftBericht(string persoon)
        {
            string bericht;

            if (IsFeest)
            {
                bericht = $"Gelukkige verjaardag! {persoon}\r\nAantal cadeaus ={ AantalCadeaus}\r\nGeniet van het verjaardagsfeestje!";
            }
            else
            {
                bericht = $"Jammer {persoon} geen verjaardagsfeest!";
            }
            return bericht;
        }
    }
}
